import { useState } from 'react'

function CommentForm({ onAddComment }) {
  const [name, setName] = useState('')
  const [text, setText] = useState('')

  function handleSubmit(event) {
    event.preventDefault()
    const trimmedName = name.trim()
    const trimmedText = text.trim()
    if (!trimmedName || !trimmedText) return

    onAddComment({ name: trimmedName, text: trimmedText })
    setName('')
    setText('')
  }

  return (
    <form className="comment-form" onSubmit={handleSubmit}>
      <label htmlFor="comment-name">Name</label>
      <input
        id="comment-name"
        name="name"
        autoComplete="name"
        maxLength={80}
        value={name}
        onChange={(event) => setName(event.target.value)}
        required
      />
      <label htmlFor="comment-text">Comment</label>
      <textarea
        id="comment-text"
        name="comment"
        maxLength={500}
        value={text}
        onChange={(event) => setText(event.target.value)}
        required
      />
      <button type="submit">Post comment</button>
    </form>
  )
}

export default CommentForm