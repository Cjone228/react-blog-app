export const posts = [
  {
    id: 1,
    category: 'Around town',
    title: 'The bookstore I found on the walk home',
    author: 'Jamie Rivera',
    date: 'October 11, 2025',
    dateTime: '2025-10-11',
    content: 'I took Cedar Street home last Saturday and ducked into a used bookstore I had somehow walked past for years. I meant to stay ten minutes; I left with two paperbacks and a list of places to go back to.',
  },
  {
    id: 2,
    category: 'At home',
    title: 'The basil survived the heat',
    author: 'Morgan Lee',
    date: 'October 04, 2025',
    dateTime: '2025-10-04',
    content: 'After a rough August on the fire escape, the basil has put out a few new leaves. First thing I have managed to keep alive all summer.',
  },
  {
    id: 3,
    category: 'On the road',
    title: 'The northbound playlist',
    author: 'Casey Bennett',
    date: 'September 27, 2025',
    dateTime: '2025-09-27',
    content: 'A few songs that made the drive up the coast feel shorter, and the one we played twice before crossing the bridge.',
  },
]