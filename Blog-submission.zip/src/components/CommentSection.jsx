import { useState } from 'react'

const startingComments = [
  {
    id: 1,
    author: 'Avery Brooks',
    date: 'October 12, 2025',
    text: 'I know the shop you mean. The little table of used cookbooks is worth a look too.',
  },
  {
    id: 2,
    author: 'Devon Price',
    date: 'October 13, 2025',
    text: 'Adding this to my Saturday route. Thanks for the tip.',
  },
]

function CommentSection() {
  const [comments, setComments] = useState(startingComments)
  const [message, setMessage] = useState('')

  function handleSubmit(event) {
    event.preventDefault()
    const trimmedMessage = message.trim()
    if (!trimmedMessage) return

    setComments((currentComments) => [
      {
        id: Date.now(),
        author: 'Guest',
        date: 'Just now',
        text: trimmedMessage,
      },
      ...currentComments,
    ])
    setMessage('')
  }

  return (
    <div className="comment-section">
      <form className="comment-form" onSubmit={handleSubmit}>
        <label className="visually-hidden" htmlFor="comment-message">Add a comment</label>
        <textarea
          id="comment-message"
          name="comment"
          placeholder="Add a comment"
          maxLength={500}
          value={message}
          onChange={(event) => setMessage(event.target.value)}
          required
        />
        <button type="submit">Submit</button>
      </form>
      <ol className="comment-list" aria-label={`${comments.length} comments`}>
        {comments.map((comment) => (
          <li className="comment" key={comment.id}>
            <div>
              <p className="comment__heading">
                <span className="comment__author">{comment.author}</span>
                <time className="comment__date">{comment.date}</time>
              </p>
              <p className="comment__text">{comment.text}</p>
            </div>
          </li>
        ))}
      </ol>
    </div>
  )
}

export default CommentSection