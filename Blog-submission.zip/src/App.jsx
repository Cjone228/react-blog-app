import './App.css'
import BlogPost from './components/BlogPost.jsx'
import CommentSection from './components/CommentSection.jsx'
import Footer from './components/Footer.jsx'
import Header from './components/Header.jsx'
import { posts } from './data/posts.js'

function App() {
  const [featuredPost, ...morePosts] = posts

  return (
    <div className="app" id="home">
      <Header />
      <main className="page-content">
        <section className="featured-story" aria-label="Featured blog post">
          <BlogPost post={featuredPost} featured />
          <div className="comments-section" aria-labelledby="comments-title">
            <h2 id="comments-title">Comments</h2>
            <CommentSection />
          </div>
        </section>

        <section className="more-posts" id="stories" aria-labelledby="stories-title">
          <h2 id="stories-title">More blog posts</h2>
          {morePosts.map((post) => <BlogPost key={post.id} post={post} />)}
        </section>
      </main>
      <Footer />
    </div>
  )
}

export default App
