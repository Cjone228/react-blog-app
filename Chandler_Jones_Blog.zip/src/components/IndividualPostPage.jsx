import { useState } from 'react'
import { Link, useParams } from 'react-router'
import CommentSection from './CommentSection.jsx'
import { posts } from '../data/posts.js'

function IndividualPostPage() {
  const { postId } = useParams()
  const post = posts.find((item) => item.id === Number(postId))

  if (!post) return <p className="not-found">That post could not be found. <Link to="/">View all posts</Link></p>
  return <PostDetail key={post.id} post={post} />
}

function PostDetail({ post }) {
  const [comments, setComments] = useState([])

  function addComment(comment) {
    setComments((currentComments) => [{ ...comment, id: Date.now(), date: 'Just now' }, ...currentComments])
  }

  return (
    <article className="post-detail">
      <Link className="back-link" to="/">← All posts</Link>
      <p className="eyebrow">{post.category}</p>
      <h1>{post.title}</h1>
      <p className="blog-post__details">
        <span><strong>Author:</strong> {post.author}</span>
        <span><strong>Date:</strong> <time dateTime={post.dateTime}>{post.date}</time></span>
      </p>
      <div className="post-detail__content">
        {post.fullContent.map((paragraph) => <p key={paragraph}>{paragraph}</p>)}
      </div>
      <section className="comments-section" aria-labelledby="comments-title">
        <h2 id="comments-title">Comments</h2>
        <CommentSection comments={comments} onAddComment={addComment} />
      </section>
    </article>
  )
}

export default IndividualPostPage