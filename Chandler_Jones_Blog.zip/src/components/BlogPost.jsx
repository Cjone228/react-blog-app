import { Link } from 'react-router'

function BlogPost({ post, featured = false }) {
  return (
    <article className={featured ? 'blog-post blog-post--featured' : 'blog-post'}>
      {featured ? (
        <h1><Link to={`/posts/${post.id}`}>{post.title}</Link></h1>
      ) : (
        <h2><Link to={`/posts/${post.id}`}>{post.title}</Link></h2>
      )}
      <p className="blog-post__content">{post.content}</p>
      <p className="blog-post__details">
        <span><strong>Author:</strong> {post.author}</span>
        <span><strong>Date:</strong> <time dateTime={post.dateTime}>{post.date}</time></span>
      </p>
      {!featured && <Link className="read-more" to={`/posts/${post.id}`}>Read post</Link>}
    </article>
  )
}

export default BlogPost