# Margin Notes

A small responsive blog built with React and Vite. Post data and sample comments are stored in JavaScript files. New comments use React state and reset when the page reloads.

## Run the app

```sh
npm install
npm run dev
```

Open the local URL printed by Vite. To create a production build, run `npm run build`. To check the code, run `npm run lint`.

## Project structure

- `src/components/` contains the header, blog post, comment section, and footer.
- `src/data/posts.js` contains the static post data.
- `src/App.jsx` assembles the page sections.
- `src/App.css` and `src/index.css` contain the page styles and design tokens.

