function BlogPost({ post, featured = false }) {
  return (
    <article className={featured ? 'blog-post blog-post--featured' : 'blog-post'}>
      {featured ? <h1>{post.title}</h1> : <h2>{post.title}</h2>}
      <p className="blog-post__content">{post.content}</p>
      <p className="blog-post__details">
        <span><strong>Author:</strong> {post.author}</span>
        <span><strong>Date:</strong> <time dateTime={post.dateTime}>{post.date}</time></span>
      </p>
    </article>
  )
}

export default BlogPost