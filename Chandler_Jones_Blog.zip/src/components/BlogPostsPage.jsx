import BlogPost from './BlogPost.jsx'
import { posts } from '../data/posts.js'

function BlogPostsPage() {
  return (
    <section className="posts-page" aria-labelledby="posts-title">
      <p className="eyebrow">Notes from around town, home, and the road</p>
      <h1 id="posts-title">The blog</h1>
      <div className="post-list">
        {posts.map((post, index) => (
          <BlogPost key={post.id} post={post} featured={index === 0} />
        ))}
      </div>
    </section>
  )
}

export default BlogPostsPage