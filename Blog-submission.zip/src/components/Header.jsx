function Header() {
  return (
    <header className="site-header">
      <div className="site-header__inner">
        <a className="site-title" href="#home">Margin Notes</a>
        <nav className="site-nav" aria-label="Main navigation">
          <a href="#home">Home</a>
          <a href="#stories">Posts</a>
          <a href="#about">About</a>
          <a href="mailto:hello@example.com">Contact</a>
        </nav>
      </div>
    </header>
  )
}

export default Header